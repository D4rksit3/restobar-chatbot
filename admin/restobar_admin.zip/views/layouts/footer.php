</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/public/js/scripts.js"></script>
<?php
// Archivo de configuración global para la zona horaria
date_default_timezone_set('America/Lima');
?>
</body>
</html>

