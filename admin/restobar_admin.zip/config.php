<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'restobar');
define('DB_PASS', '');
define('DB_NAME', 'restobar');
?>
